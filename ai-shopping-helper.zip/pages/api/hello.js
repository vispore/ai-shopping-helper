export default function handler(req, res) {
  res.status(200).json({ message: '안녕하세요, AI 쇼핑 조력자입니다!' });
}
