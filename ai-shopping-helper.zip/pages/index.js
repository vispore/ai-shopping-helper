export default function Home() {
  return (
    <div>
      <h1>AI 쇼핑 조력자</h1>
      <p>환영합니다! 이 프로젝트는 AI 쇼핑 조력자 앱입니다.</p>
    </div>
  );
}
